use eframe::egui;
use rand::RngCore;

use crate::{battle::{command::Command, engine::engine::{self, StepRequest}, state::{Outcome, Team, battle_state::BattleState, creature_state::CreatureState, field::PositionId}}, model::registry::Registry, rl::{agent::Agent, encoder, mask::Mask, moveslot::{MOVESLOT_COUNT, Moveslot}}};


pub struct BattleApp<R>
where
	R: RngCore,
{
	pub battle: BattleState,
	pub agent: Box<dyn Agent>,
	pub log: Vec<String>,
	pub registry: Registry,
	pub player_team: Team,
	pub rng: R,
	/// What the engine is waiting for.
	///
	/// This used to be thrown away, which is what let creatures get attacked on
	/// the way in: after a faint the engine returns `NeedsReplacements`, but the
	/// window went straight back to the normal move menu. The fainted creature's
	/// mask allows no moves, so the player could only pick a switch — and that
	/// switch was then submitted as an ordinary turn action, alongside a freely
	/// chosen attack from the opponent. The replacement ate a hit that should
	/// never have happened.
	///
	/// Start a new battle at `NeedsActions`.
	pub step_request: StepRequest,
}

impl <R> eframe::App for BattleApp<R>
where
	R: RngCore
{
	fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
		self.show_battle_state(ui);

		// Driven by what the engine actually asked for, rather than by
		// re-deriving the situation from the battle state.
		match self.step_request.clone() {
			StepRequest::Finished(Outcome::Win { team }) if team == self.player_team => {
				ui.label("you win!!");
			}
			StepRequest::Finished(Outcome::Win { team: _ }) => {
				ui.label("you lose...");
			}
			StepRequest::Finished(Outcome::Draw) => {
				ui.label("it's a draw?");
			}
			StepRequest::NeedsReplacements(positions) => {
				self.display_replacement_options(ui, &positions);
			}
			StepRequest::NeedsActions => {
				self.display_move_options(ui);
			}
		}
	}
}

impl <R> BattleApp<R>
where
	R: RngCore
{
	/// Run one engine step and remember what it asks for next.
	fn submit(&mut self, commands: Vec<Command>) {
		let step_result = engine::step(self.battle.clone(), commands, &self.registry, &mut self.rng);
		self.battle = step_result.battle_state;
		self.step_request = step_result.step_request;
	}

	/// Ask the agent to pick a replacement for one of its own positions.
	fn agent_replacement(&mut self, pos: PositionId) -> Command {
		let agent_team = self.player_team.other();
		// `replacement: true` matches how the encoder is called during training,
		// so the agent sees the same kind of position it was trained on.
		let encoding = encoder::encode(&self.battle, &self.registry, true, &agent_team);
		let mask = Mask::from_battle_state(&agent_team, pos, &self.battle);
		let chosen = self.agent.choose_move(&encoding, &mask, &mut self.rng);
		chosen.to_command(pos, &self.battle, &self.registry)
	}

	/// The replacement phase: nobody attacks, both sides just send something in.
	///
	/// Because these commands go to the engine on their own, the step contains no
	/// move actions at all — so the creature coming in cannot be hit on the way.
	fn display_replacement_options(&mut self, ui: &mut egui::Ui, positions: &[PositionId]) {
		let agent_team = self.player_team.other();
		let player_positions: Vec<PositionId> =
			positions.iter().filter(|p| p.team() == self.player_team).copied().collect();
		let agent_positions: Vec<PositionId> =
			positions.iter().filter(|p| p.team() == agent_team).copied().collect();

		// The agent's side needs no input from us, so decide it up front.
		let mut commands: Vec<Command> = Vec::new();
		for pos in &agent_positions {
			commands.push(self.agent_replacement(*pos));
		}

		if player_positions.is_empty() {
			// Only the opponent fainted. Resolve immediately rather than showing
			// the human an empty menu and stalling the battle.
			self.submit(commands);
			return;
		}

		ui.heading("your creature fainted - choose a replacement:");

		// Singles, so there is at most one position to fill.
		let pos = player_positions[0];
		let mut chosen: Option<Moveslot> = None;
		egui::Grid::new("replacements").show(ui, |ui| {
			chosen = self.generate_switch_buttons(ui, pos);
		});

		if let Some(moveslot) = chosen {
			commands.push(moveslot.to_command(pos, &self.battle, &self.registry));
			self.submit(commands);
		}
	}

	fn display_move_options(&mut self, ui: &mut egui::Ui) {
		let player_position = self.battle.field.team_positions(&self.player_team)[0];
		let agent_position = self.battle.field.team_positions(&self.player_team.other())[0];

		let mut move_selected: Option<Moveslot> = None;

		egui::Grid::new("moves").show(ui, |ui| {
			move_selected = self.generate_moveslot_buttons(ui, player_position);
		});

		if let Some(moveslot) = move_selected {
			// Encoded from the agent's own side, not the player's — the agent here
			// is whichever team the human is not.
			let agent_team = self.player_team.other();
			let encoding = encoder::encode(&self.battle, &self.registry, false, &agent_team);
			let agent_mask = Mask::from_battle_state(&agent_team, agent_position, &self.battle);
			let agent_moveslot = self.agent.choose_move(&encoding, &agent_mask, &mut self.rng);
			let commands = vec![
				agent_moveslot.to_command(agent_position, &self.battle, &self.registry),
				moveslot.to_command(player_position, &self.battle, &self.registry),
			];
			self.submit(commands);
		}
	}

	fn display_creature_state(&self, ps: &CreatureState) -> String {
		let species_data = self.registry.get_species_data(ps.species_id);
		let ability = match ps.ability {
			Some(ability) => ability.name(),
			None => "none",
		};

		format!(
			"{} [{}]: HP {} out of {}, with status: {}",
			species_data.name, ability, ps.current_hp, ps.max_hp, ps.non_vol_status
		)
	}
	fn display_team(&self, team: &Team, ui: &mut egui::Ui) {
		for m in self.battle.field.team(team) {
			let ps = self.battle.roster.get_mon(*m).unwrap();
			ui.strong(self.display_creature_state(&ps));
		}
	}
	fn show_battle_state(&self, ui: &mut egui::Ui) {

		ui.heading(format!("your active(s):"));
		self.display_team(&self.player_team, ui);

		ui.heading(format!("their active(s):"));
		self.display_team(&self.player_team.other(), ui);
	}

	fn generate_moveslot_buttons(&self, ui: &mut egui::Ui, position: PositionId) -> Option<Moveslot> {
		let mut final_moveslot = None;
		let mask = Mask::from_battle_state(&self.player_team, position, &self.battle);
		for moveslot in Moveslot::all_moveslots() {
			if ui.add_enabled(
				mask.allowed[moveslot.to_number()],
				egui::Button::new(self.generate_moveslot_name(moveslot, position))).clicked()
			{
					final_moveslot = Some(moveslot);
			}
			if let Moveslot::Slot(3) = moveslot {
				ui.end_row();
				ui.end_row();
			}
		}
		final_moveslot
	}

	/// Switch buttons only — a replacement is not a choice between attacking and
	/// switching, so the move slots are not offered at all.
	fn generate_switch_buttons(&self, ui: &mut egui::Ui, position: PositionId) -> Option<Moveslot> {
		let mut final_moveslot = None;
		let mask = Mask::from_battle_state(&self.player_team, position, &self.battle);
		for moveslot in Moveslot::all_moveslots() {
			let slot_number = moveslot.to_number();
			if slot_number < MOVESLOT_COUNT {
				continue;
			}
			if ui.add_enabled(
				mask.allowed[slot_number],
				egui::Button::new(self.generate_moveslot_name(moveslot, position))).clicked()
			{
				final_moveslot = Some(moveslot);
			}
		}
		final_moveslot
	}

	fn generate_moveslot_name(&self, moveslot: Moveslot, position: PositionId) -> String {
		match moveslot {
			Moveslot::Slot(n) => {
				let option_mv = self.battle.get_mon(position).unwrap().moves.get(n);
				if let Some(mv) = option_mv {
					self.registry.get_move(*mv).name.clone()
				} else {
					String::from("empty")
				}
			}
			Moveslot::Switch(n) => {
				if let Some(target) = self.battle.get_mon_from_team(&self.player_team, n) {
					self.registry.get_species_data(target.species_id).name.clone()
				} else {
					String::from("nobody")
				}
			}
		}
	}

}
